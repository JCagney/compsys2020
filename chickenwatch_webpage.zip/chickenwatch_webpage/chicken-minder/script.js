window.onload = function (){
  // Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyA5tMYw5mcuXKcQEDCrkgPnNIZf7k9U3ME",
    authDomain: "chickenminder484-64635.firebaseapp.com",
    databaseURL: "https://chickenminder484-64635-default-rtdb.firebaseio.com",
    projectId: "chickenminder484-64635",
    storageBucket: "chickenminder484-64635.appspot.com",
    messagingSenderId: "486889781985",
    appId: "1:486889781985:web:aac701e4fb44fb494115a0"
};

firebase.initializeApp(firebaseConfig);

// Get a reference to the file storage service
const storage = firebase.storage();
// Get a reference to the database service
const database = firebase.database();

// Create camera and readings database references
const camRef = database.ref("file");
const readingRef = database.ref("readings");

// Sync on any updates to the DB. THIS CODE RUNS EVERY TIME AN UPDATE OCCURS ON THE DB.
camRef.limitToLast(1).on("value", function(snapshot) {
  snapshot.forEach(function(childSnapshot) {
    const image = childSnapshot.val()["image"];
    const time = childSnapshot.val()["timestamp"];
    const storageRef = storage.ref(image);

    storageRef
      .getDownloadURL()
      .then(function(url) {
        console.log(url);
        document.getElementById("photo").src = url;
        document.getElementById("time").innerText = time;
      })
      .catch(function(error) {
        console.log(error);
      });
  });
});

  
readingRef.limitToLast(1).on("value", function(snapshot) {
  snapshot.forEach(function(childSnapshot) {
    const temp = childSnapshot.val()["temp"];
    const time = childSnapshot.val()["time"];
    const pressure = childSnapshot.val()["pressure"];
    const humidity = childSnapshot.val()["humidity"];
    document.getElementById("temp").innerText = temp;
    document.getElementById("readingTime").innerText = time;
    document.getElementById("pressure").innerText = pressure;
    document.getElementById("humidity").innerText = humidity;
  });
});
  

// Get the last 10 photos from storage and add them to the "imagespan" element
camRef.orderByChild('timestamp').limitToLast(10).on("value", function(snapshot) {
  snapshot.forEach(function(childSnapshot) {
    const image = childSnapshot.val()["image"];
    const time = childSnapshot.val()["timestamp"];
    const storageRef = storage.ref(image);
    const url = storageRef.getDownloadURL();  
    storageRef.getDownloadURL().then(function(url) {
    document.getElementById("imagespan").innerHTML += "<img src="+url+"></img> <br>"+ time + "<br>"; 
    }); 
   });
});



}


                  