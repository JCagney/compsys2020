from urllib.request import urlopen
import  json
import firebase_admin 
from firebase_admin import credentials, db
from sense_hat import SenseHat
import datetime
import time

sense = SenseHat() 

sense.clear()

# firebase creds and app 
cred=credentials.Certificate('./serviceAccountKey.json')
firebase_admin.initialize_app(cred, {
    'storageBucket': 'chickenminder484-64635.appspot.com',
    'databaseURL': 'https://chickenminder484-64635-default-rtdb.firebaseio.com/'
})

# firebase refs 
ref = db.reference('/')
home_ref = ref.child('readings')

WRITE_API_KEY='M87G86OQIPSX2Y7I'

baseURL='https://api.thingspeak.com/update?api_key=%s' % WRITE_API_KEY

# Thingspeak write method
def writeData(temp, humidity, pressure):
    conn = urlopen(baseURL + '&field1=%s' % (temp) +'&field2=%s' % (humidity) + '&field3=%s' % (pressure))
    print(conn.read())
    conn.close()

while True:
    currentTime = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    temp=round(sense.get_temperature(),2)
    humidity=round(sense.get_humidity(),2)
    pressure=round(sense.get_pressure(),2)
    
    # push data to Firebase db
    home_ref.push({
            'time': currentTime,
            'temp': temp,
            'humidity': humidity,
            'pressure': pressure}
    )

    # write data to Thingspeak   
    writeData(temp, humidity, pressure)
    # wait 1 hour 
    time.sleep(3600)

