from sense_hat import SenseHat, ACTION_PRESSED, ACTION_HELD, ACTION_RELEASED
import time
sense = SenseHat()

# listen for joystick to be pressed on sensehat, turn on white LED lights for 60 seconds when it is 
while True:
    for event in sense.stick.get_events():
        if event.action == ACTION_PRESSED:
            sense.clear()
            sense.clear(255,255,255)
            time.sleep(60) 
            sense.clear()


