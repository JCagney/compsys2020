from flask import Flask, request
from flask_cors import CORS
import photo

app = Flask(__name__)
CORS(app)

@app.route('/project/photo',methods=['POST'])
def photo_post():
   take_photo.py 

if __name__=="__main__":
   app.run(host='0.0.0.0', port=5000, debug=True)  
