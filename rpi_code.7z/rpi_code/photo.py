from picamera import PiCamera
import datetime
import storeFileFB
import os
from sense_hat import SenseHat
import time
from flask import Flask, request
from flask_cors import CORS
from fractions import Fraction

app = Flask(__name__)
CORS(app)

# method to take photo (dark mode settings), then invoke firebase storage and db methods and finally delete local f$
@app.route('/project/photo',methods=['POST'])
def post_photo():
    sense = SenseHat()  
    camera = PiCamera()         
    camera.framerate = Fraction(1,6)
    camera.shutter_speed = 6000000
    camera.exposure_mode = 'off'
    camera.iso = 800
    sense.clear((255,255,255))
    camera.start_preview()
    time.sleep(8)
    fileName = datetime.datetime.now().strftime("%d%m%Y%H%M%S")

    camera.capture(fileLoc) 
    sense.clear()
    camera.close()
 
    storeFileFB.store_file(fileLoc)
    storeFileFB.push_db(fileLoc, currentTime)
    os.remove(fileLoc)
    return "photo taken at "+ currentTime + "\n"
    
# run app listening for HTTP request on port 5000  
if __name__=="__main__":
   app.run(host='0.0.0.0', port=5000, debug=True) 
